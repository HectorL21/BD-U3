/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_bases_de_datos;

import java.util.logging.Level;
import java.util.logging.Logger;
//Para la conexión
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//Para ejecutar instrucciones
import java.sql.Statement;
import java.sql.ResultSet;


/**
 *
 * @author moral
 */
public class Conexion_BD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //SOLO NOS CONECTAMOS UNA VEZ AL SERVIDOR
        //Esto debería estar en una clase conexión pero lo vamos a poner todo 
        //aquí por comodidad y para la explicación
        Connection connection;
        try{
            //CARGAMOS LA LIBRERIA JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            //CONEXION
            String url = "jdbc:mysql://localhost:3306/eva3";
            connection = DriverManager.getConnection(url,"root", "root");
            
            //CONSULTA SQL
            Statement statement = connection.createStatement();{
            //OBTENER UN RESULTSET (un listado de filas)
            ResultSet resultSet;
            resultSet = statement.executeQuery(
                    "select * from actor limit 50;"
            );
            
            int actor_id;
            String f_name;
            String l_name;
            while(resultSet.next()){//true mientras haya datos
                actor_id = resultSet.getInt("actor_id");
                f_name = resultSet.getString("first_name");
                l_name = resultSet.getString("last_name");
                System.out.println("ID: " + actor_id + "\n" +
                "First name: " + f_name + "\n" + 
                "Last name: " + l_name + "\n");
            }
        }
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion_BD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("SQLEception: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("Error: " + ex.getErrorCode());
        }
    }
    
}
